﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Data.Entities;

[PrimaryKey("IdArticulo", "IdTienda")]
[Table("Articulo_Tienda")]
public partial class ArticuloTienda
{
    [Key]
    public int IdArticulo { get; set; }

    [Key]
    public int IdTienda { get; set; }

    public DateOnly Fecha { get; set; }

    [ForeignKey("IdArticulo")]
    [InverseProperty("ArticuloTienda")]
    public virtual Articulo IdArticuloNavigation { get; set; } = null!;

    [ForeignKey("IdTienda")]
    [InverseProperty("ArticuloTienda")]
    public virtual Tienda IdTiendaNavigation { get; set; } = null!;
}

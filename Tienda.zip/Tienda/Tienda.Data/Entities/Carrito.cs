﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Data.Entities;

[Table("Carrito")]
public partial class Carrito
{
    [Key]
    public int IdCarrito { get; set; }

    public int IdCliente { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? FechaCreacion { get; set; } = DateTime.Now;

    [InverseProperty("IdCarritoNavigation")]
    public virtual ICollection<CarritoDetalle> CarritoDetalles { get; set; } = new List<CarritoDetalle>();

    [ForeignKey("IdCliente")]
    [InverseProperty("Carritos")]
    public virtual Cliente IdClienteNavigation { get; set; } = null!;
}

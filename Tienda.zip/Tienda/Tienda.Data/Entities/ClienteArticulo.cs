﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Data.Entities;

[PrimaryKey("IdCliente", "IdArticulo", "Fecha")]
[Table("Cliente_Articulo")]
public partial class ClienteArticulo
{
    [Key]
    public int IdCliente { get; set; }

    [Key]
    public int IdArticulo { get; set; }

    [Key]
    public DateOnly Fecha { get; set; }

    [ForeignKey("IdArticulo")]
    [InverseProperty("ClienteArticulos")]
    public virtual Articulo IdArticuloNavigation { get; set; } = null!;

    [ForeignKey("IdCliente")]
    [InverseProperty("ClienteArticulos")]
    public virtual Cliente IdClienteNavigation { get; set; } = null!;
}

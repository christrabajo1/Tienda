﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Data.Entities;

[Table("CarritoDetalle")]
public partial class CarritoDetalle
{
    [Key]
    public int IdDetalle { get; set; }

    public int IdCarrito { get; set; }

    public int IdArticulo { get; set; }

    public int Cantidad { get; set; }

    [ForeignKey("IdArticulo")]
    [InverseProperty("CarritoDetalles")]
    public virtual Articulo IdArticuloNavigation { get; set; } = null!;

    [ForeignKey("IdCarrito")]
    [InverseProperty("CarritoDetalles")]
    public virtual Carrito IdCarritoNavigation { get; set; } = null!;
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Data.Entities;

public partial class Tienda
{
    [Key]
    public int IdTienda { get; set; }

    [StringLength(100)]
    public string Sucursal { get; set; } = null!;

    [StringLength(255)]
    public string? Direccion { get; set; }

    [InverseProperty("IdTiendaNavigation")]
    public virtual ICollection<ArticuloTienda> ArticuloTienda { get; set; } = new List<ArticuloTienda>();
}

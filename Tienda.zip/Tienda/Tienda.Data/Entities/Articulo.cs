﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Data.Entities;

[Index("Codigo", Name = "UQ__Articulo__06370DAC6A20BC9B", IsUnique = true)]
public partial class Articulo
{
    [Key]
    public int IdArticulo { get; set; }

    [StringLength(50)]
    public string Codigo { get; set; } = null!;

    [StringLength(255)]
    public string? Descripcion { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal? Precio { get; set; }

    [StringLength(255)]
    public string? Imagen { get; set; }

    public int? Stock { get; set; }

    [InverseProperty("IdArticuloNavigation")]
    public virtual ICollection<ArticuloTienda> ArticuloTienda { get; set; } = new List<ArticuloTienda>();

    [InverseProperty("IdArticuloNavigation")]
    public virtual ICollection<CarritoDetalle> CarritoDetalles { get; set; } = new List<CarritoDetalle>();

    [InverseProperty("IdArticuloNavigation")]
    public virtual ICollection<ClienteArticulo> ClienteArticulos { get; set; } = new List<ClienteArticulo>();
}

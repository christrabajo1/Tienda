﻿namespace Tienda.Data
{
    public class Class1
    {

    }
}

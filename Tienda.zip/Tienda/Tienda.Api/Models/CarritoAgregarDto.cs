﻿namespace Tienda.Api.Models
{
    public class CarritoAgregarDto
    {
        public int IdArticulo { get; set; }
        public int Cantidad { get; set; }
    }
}

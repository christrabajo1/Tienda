﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tienda.Data.Context;
using Tienda.Data.Entities;

namespace Tienda.Api.Controllers
{
    [ApiController]
    [Route("api/tienda")]
    public class TiendaArticuloController : ControllerBase
    {
        private readonly TiendaDbContext _context;

        public TiendaArticuloController(TiendaDbContext context)
        {
            _context = context;
        }

        [HttpPost("{idTienda}/agregar-articulo/{idArticulo}")]
        public async Task<IActionResult> AgregarArticuloATienda(int idTienda, int idArticulo)
        {
            var tienda = await _context.Tiendas.FindAsync(idTienda);
            var articulo = await _context.Articulos.FindAsync(idArticulo);

            if (tienda == null || articulo == null)
                return NotFound("La tienda o el artículo no existen.");

            var existeRelacion = await _context.ArticuloTienda
                .AnyAsync(at => at.IdTienda == idTienda && at.IdArticulo == idArticulo);

            if (existeRelacion)
                return Conflict("El artículo ya está asignado a esta tienda.");

            var relacion = new ArticuloTienda
            {
                IdTienda = idTienda,
                IdArticulo = idArticulo,
                Fecha = DateOnly.FromDateTime(DateTime.Now)
            };

            _context.ArticuloTienda.Add(relacion);
            await _context.SaveChangesAsync();

            return Ok("Artículo agregado correctamente a la tienda.");
        }

        [HttpGet("{idTienda}/articulos")]
        public async Task<IActionResult> ObtenerArticulosPorTienda(int idTienda)
        {
            var articulos = await _context.ArticuloTienda
                .Include(at => at.IdArticuloNavigation)
                .Where(at => at.IdTienda == idTienda)
                .Select(at => new
                {
                    at.IdArticulo,
                    at.IdTienda,
                    at.Fecha,
                    at.IdArticuloNavigation.Descripcion,
                    at.IdArticuloNavigation.Precio
                })
                .ToListAsync();

            if (!articulos.Any())
                return NotFound("Esta tienda no tiene artículos asignados.");

            return Ok(articulos);
        }
    }
}

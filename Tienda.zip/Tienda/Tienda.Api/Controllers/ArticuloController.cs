﻿using Microsoft.AspNetCore.Mvc;
using Tienda.Business.Interfaces;
using Tienda.Data.Entities;

namespace Tienda.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ArticuloController : ControllerBase
    {
        private readonly IArticuloService _articuloService;

        public ArticuloController(IArticuloService articuloService)
        {
            _articuloService = articuloService;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Articulo articulo)
        {
            if (articulo == null)
                return BadRequest("Datos del artículo no válidos.");

            var creado = await _articuloService.CreateAsync(articulo);
            return CreatedAtAction(nameof(GetById), new { id = creado.IdArticulo }, creado);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var articulos = await _articuloService.GetAllAsync();
            return Ok(articulos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var articulo = await _articuloService.GetByIdAsync(id);
            if (articulo == null)
                return NotFound();
            return Ok(articulo);
        }

        [HttpGet("buscar/{texto}")]
        public async Task<IActionResult> BuscarPorDescripcion(string texto)
        {
            var articulos = await _articuloService.BuscarPorDescripcionAsync(texto);
            return Ok(articulos);
        }

        [HttpGet("tienda/{idTienda}")]
        public async Task<IActionResult> ObtenerPorTienda(int idTienda)
        {
            var articulos = await _articuloService.ObtenerPorTiendaAsync(idTienda);
            return Ok(articulos);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Articulo articulo)
        {
            if (id != articulo.IdArticulo)
                return BadRequest("El ID no coincide.");

            var actualizado = await _articuloService.UpdateAsync(articulo);
            return Ok(actualizado);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var eliminado = await _articuloService.DeleteAsync(id);
            if (!eliminado)
                return NotFound();

            return NoContent();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tienda.Data.Context;
using Tienda.Data.Entities;

namespace Tienda.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ArticuloTiendaController : ControllerBase
    {
        private readonly TiendaDbContext _context;

        public ArticuloTiendaController(TiendaDbContext context)
        {
            _context = context;
        }

        [HttpPost("{idTienda}/articulo/{idArticulo}")]
        public async Task<IActionResult> AsociarArticuloATienda(int idTienda, int idArticulo)
        {
            var existe = await _context.ArticuloTienda
                .FirstOrDefaultAsync(a => a.IdArticulo == idArticulo && a.IdTienda == idTienda);

            if (existe != null)
                return Conflict("El artículo ya está asociado a esta tienda.");

            var nuevaRelacion = new ArticuloTienda
            {
                IdArticulo = idArticulo,
                IdTienda = idTienda,
                Fecha = DateOnly.FromDateTime(DateTime.Now)
            };

            _context.ArticuloTienda.Add(nuevaRelacion);
            await _context.SaveChangesAsync();

            return Ok("Artículo asociado a la tienda correctamente.");
        }

        [HttpGet("{idTienda}/articulos")]
        public async Task<IActionResult> ObtenerArticulosDeTienda(int idTienda)
        {
            var articulos = await _context.ArticuloTienda
                .Include(a => a.IdArticuloNavigation)
                .Where(a => a.IdTienda == idTienda)
                .Select(a => new
                {
                    a.IdArticulo,
                    a.IdArticuloNavigation.Descripcion,
                    a.IdArticuloNavigation.Precio,
                    a.Fecha
                })
                .ToListAsync();

            if (!articulos.Any())
                return NoContent();

            return Ok(articulos);
        }
    }
}

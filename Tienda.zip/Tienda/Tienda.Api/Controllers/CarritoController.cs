﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tienda.Api.Models;
using Tienda.Business.Interfaces;
using Tienda.Data.Context;
using Tienda.Data.Entities;

namespace Tienda.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CarritoController : ControllerBase
    {
        private readonly ICarritoService _carritoService;
        private readonly TiendaDbContext _context; 

        public CarritoController(ICarritoService carritoService, TiendaDbContext context)
        {
            _carritoService = carritoService;
            _context = context;
        }

        [HttpPost("crear/{idCliente}")]
        public async Task<IActionResult> CrearCarrito(int idCliente)
        {
            var carrito = await _carritoService.CrearCarritoAsync(idCliente);
            return Ok(carrito);
        }

        [HttpPost("{idCarrito}/agregar")]
        public async Task<IActionResult> AgregarArticulo(int idCarrito, [FromBody] CarritoAgregarDto dto)
        {
            var resultado = await _carritoService.AgregarArticuloAsync(idCarrito, dto.IdArticulo, dto.Cantidad);
            return Ok(resultado);
        }

        [HttpGet("{idCliente}")]
        public async Task<IActionResult> ObtenerCarrito(int idCliente)
        {
            var carrito = await _carritoService.ObtenerCarritoAsync(idCliente);
            if (carrito == null)
                return NotFound($"El cliente {idCliente} no tiene carrito activo.");

            return Ok(carrito);
        }

        [HttpDelete("{idCarrito}/articulo/{idArticulo}")]
        public async Task<IActionResult> EliminarArticulo(int idCarrito, int idArticulo)
        {
            var eliminado = await _carritoService.EliminarArticuloAsync(idCarrito, idArticulo);
            if (!eliminado)
                return NotFound("Artículo no encontrado en el carrito.");

            return Ok("Artículo eliminado del carrito.");
        }

        [HttpDelete("vaciar/{idCarrito}")]
        public async Task<IActionResult> VaciarCarrito(int idCarrito)
        {
            var vaciado = await _carritoService.VaciarCarritoAsync(idCarrito);
            if (!vaciado)
                return NotFound("El carrito ya estaba vacío o no existe.");

            return Ok("Carrito vaciado correctamente.");
        }

        [HttpPost("{idCarrito}/finalizar")]
        public async Task<IActionResult> FinalizarCompra(int idCarrito)
        {
            var carrito = await _carritoService.ObtenerCarritoAsyncPorId(idCarrito);
            if (carrito == null || !carrito.CarritoDetalles.Any())
                return BadRequest("El carrito está vacío o no existe.");

            foreach (var detalle in carrito.CarritoDetalles)
            {
                var compra = new ClienteArticulo
                {
                    IdCliente = carrito.IdCliente,
                    IdArticulo = detalle.IdArticulo,
                    Fecha = DateOnly.FromDateTime(DateTime.Now)
                };

                _context.ClienteArticulos.Add(compra);
            }

            _context.CarritoDetalles.RemoveRange(carrito.CarritoDetalles);
            await _context.SaveChangesAsync();

            return Ok("Compra finalizada correctamente.");
        }
    }
}

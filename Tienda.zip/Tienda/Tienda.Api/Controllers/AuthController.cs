﻿using Microsoft.AspNetCore.Mvc;
using Tienda.Business.Interfaces;
using Tienda.Api.Models.Auth;

namespace Tienda.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var token = await _authService.LoginAsync(request.Correo, request.Contrasena);
            if (token == null)
                return Unauthorized("Correo o contraseña incorrectos.");

            return Ok(new { token });
        }
    }
}

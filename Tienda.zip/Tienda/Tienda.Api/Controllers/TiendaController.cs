﻿using Microsoft.AspNetCore.Mvc;
using Tienda.Business.Interfaces;
using TiendaEntity = Tienda.Data.Entities.Tienda;


namespace Tienda.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TiendaController : ControllerBase
    {
        private readonly ITiendaService _tiendaService;

        public TiendaController(ITiendaService tiendaService)
        {
            _tiendaService = tiendaService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var tiendas = await _tiendaService.GetAllAsync();
            if (tiendas == null || !tiendas.Any())
                return NoContent();

            return Ok(tiendas);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var tienda = await _tiendaService.GetByIdAsync(id);
            if (tienda == null)
                return NotFound($"No se encontró la tienda con ID {id}.");

            return Ok(tienda);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] TiendaEntity tienda)
        {
            if (tienda == null)
                return BadRequest("Los datos de la tienda no pueden ser nulos.");

            await _tiendaService.CreateAsync(tienda);
            return CreatedAtAction(nameof(GetById), new { id = tienda.IdTienda }, tienda);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] TiendaEntity tienda)
        {
            if (tienda == null || id != tienda.IdTienda)
                return BadRequest("Datos inválidos para la actualización.");

            var existente = await _tiendaService.GetByIdAsync(id);
            if (existente == null)
                return NotFound($"No se encontró la tienda con ID {id}.");

            await _tiendaService.UpdateAsync(tienda);
            return Ok(tienda);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var existente = await _tiendaService.GetByIdAsync(id);
            if (existente == null)
                return NotFound($"No se encontró la tienda con ID {id}.");

            await _tiendaService.DeleteAsync(id);
            return Ok($"Tienda con ID {id} eliminada correctamente.");
        }
    }
}


﻿namespace Tienda.Entities
{
    public class Class1
    {

    }
}

﻿using Microsoft.EntityFrameworkCore;
using Tienda.Business.Interfaces;
using Tienda.Data.Context;
using Tienda.Data.Entities;

namespace Tienda.Business.Services
{
    public class ArticuloService : GenericService<Articulo>, IArticuloService
    {
        private readonly TiendaDbContext _context;

        public ArticuloService(TiendaDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Articulo>> BuscarPorDescripcionAsync(string descripcion)
        {
            return await _context.Articulos
                .Where(a => a.Descripcion.Contains(descripcion))
                .ToListAsync();
        }

        public async Task<IEnumerable<Articulo>> ObtenerPorTiendaAsync(int idTienda)
        {
            return await _context.ArticuloTienda
                .Where(at => at.IdTienda == idTienda)
                .Select(at => at.IdArticuloNavigation)
                .ToListAsync();
        }
    }
}


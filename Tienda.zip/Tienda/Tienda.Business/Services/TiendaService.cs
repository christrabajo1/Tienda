﻿using Microsoft.EntityFrameworkCore;
using Tienda.Business.Interfaces;
using Tienda.Data.Context;
using Tienda.Data.Entities;
using TiendaEntity = Tienda.Data.Entities.Tienda; 

namespace Tienda.Business.Services
{
    public class TiendaService : GenericService<TiendaEntity>, ITiendaService
    {
        private readonly TiendaDbContext _context;

        public TiendaService(TiendaDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<TiendaEntity>> BuscarPorSucursalAsync(string nombreSucursal)
        {
            return await _context.Tiendas
                .Where(t => t.Sucursal.Contains(nombreSucursal))
                .ToListAsync();
        }
    }
}


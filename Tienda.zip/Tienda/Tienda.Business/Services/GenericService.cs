﻿using Microsoft.EntityFrameworkCore;
using Tienda.Business.Interfaces;
using Tienda.Data.Context;

namespace Tienda.Business.Services
{
    public class GenericService<T> : IGenericService<T> where T : class
    {
        private readonly TiendaDbContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericService(TiendaDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        public async Task<IEnumerable<T>> GetAllAsync()
            => await _dbSet.ToListAsync();

        public async Task<T?> GetByIdAsync(int id)
            => await _dbSet.FindAsync(id);

        public async Task<T> CreateAsync(T entity)
        {
            _dbSet.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<T> UpdateAsync(T entity)
        {
            var keyName = _context.Model.FindEntityType(typeof(T))?
                .FindPrimaryKey()?
                .Properties
                .Select(x => x.Name)
                .FirstOrDefault();

            if (keyName != null)
            {
                var keyValue = entity.GetType().GetProperty(keyName)?.GetValue(entity);
                var local = _context.Set<T>().Local
                    .FirstOrDefault(e => e.GetType().GetProperty(keyName)?.GetValue(e).Equals(keyValue) == true);

                if (local != null)
                    _context.Entry(local).State = EntityState.Detached;
            }

            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return entity;
        }



        public async Task<bool> DeleteAsync(int id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null) return false;
            _dbSet.Remove(entity);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}

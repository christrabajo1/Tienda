﻿using Microsoft.EntityFrameworkCore;
using Tienda.Business.Interfaces;
using Tienda.Data.Context;
using Tienda.Data.Entities;

namespace Tienda.Business.Services
{
    public class ClienteService : GenericService<Cliente>, IClienteService
    {
        private readonly TiendaDbContext _context;

        public ClienteService(TiendaDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Cliente>> BuscarPorNombreAsync(string nombre)
        {
            return await _context.Clientes
                .Where(c => c.Nombre.Contains(nombre))
                .ToListAsync();
        }
    }
}


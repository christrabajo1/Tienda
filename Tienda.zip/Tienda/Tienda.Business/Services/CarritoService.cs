﻿using Microsoft.EntityFrameworkCore;
using Tienda.Business.Interfaces;
using Tienda.Data.Context;
using Tienda.Data.Entities;

namespace Tienda.Business.Services
{
    public class CarritoService : ICarritoService
    {
        private readonly TiendaDbContext _context;

        public CarritoService(TiendaDbContext context)
        {
            _context = context;
        }

        public async Task<Carrito> CrearCarritoAsync(int idCliente)
        {
            var carritoExistente = await _context.Carritos
                .Include(c => c.CarritoDetalles)
                .FirstOrDefaultAsync(c => c.IdCliente == idCliente);

            if (carritoExistente != null)
                return carritoExistente;

            var nuevo = new Carrito
            {
                IdCliente = idCliente,
                FechaCreacion = DateTime.Now
            };

            _context.Carritos.Add(nuevo);
            await _context.SaveChangesAsync();

            return nuevo;
        }

        public async Task<CarritoDetalle> AgregarArticuloAsync(int idCarrito, int idArticulo, int cantidad)
        {

            var articuloExiste = await _context.Articulos.AnyAsync(a => a.IdArticulo == idArticulo);
            if (!articuloExiste)
                throw new Exception($"El artículo con Id {idArticulo} no existe.");


            var detalleExistente = await _context.CarritoDetalles
                .FirstOrDefaultAsync(d => d.IdCarrito == idCarrito && d.IdArticulo == idArticulo);

            if (detalleExistente != null)
            {
                detalleExistente.Cantidad += cantidad;
            }
            else
            {
                detalleExistente = new CarritoDetalle
                {
                    IdCarrito = idCarrito,
                    IdArticulo = idArticulo,
                    Cantidad = cantidad
                };
                _context.CarritoDetalles.Add(detalleExistente);
            }

            await _context.SaveChangesAsync();
            return detalleExistente;
        }

        public async Task<Carrito?> ObtenerCarritoAsync(int idCliente)
        {
            return await _context.Carritos
                .Include(c => c.CarritoDetalles)
                .ThenInclude(cd => cd.IdArticuloNavigation)
                .FirstOrDefaultAsync(c => c.IdCliente == idCliente);
        }

        public async Task<bool> EliminarArticuloAsync(int idCarrito, int idArticulo)
        {
            var detalle = await _context.CarritoDetalles
                .FirstOrDefaultAsync(d => d.IdCarrito == idCarrito && d.IdArticulo == idArticulo);

            if (detalle == null)
                return false;

            _context.CarritoDetalles.Remove(detalle);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> VaciarCarritoAsync(int idCarrito)
        {
            var detalles = _context.CarritoDetalles.Where(d => d.IdCarrito == idCarrito);
            if (!detalles.Any())
                return false;

            _context.CarritoDetalles.RemoveRange(detalles);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Carrito?> ObtenerCarritoAsyncPorId(int idCarrito)
        {
            return await _context.Carritos
                .Include(c => c.CarritoDetalles)
                .ThenInclude(cd => cd.IdArticuloNavigation)
                .FirstOrDefaultAsync(c => c.IdCarrito == idCarrito);
        }

    }
}

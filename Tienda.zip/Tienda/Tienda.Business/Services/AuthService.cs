﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Tienda.Data.Context;
using Tienda.Data.Entities;
using Tienda.Business.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Tienda.Business.Services
{
    public class AuthService : IAuthService
    {
        private readonly TiendaDbContext _context;
        private readonly IConfiguration _config;

        public AuthService(TiendaDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        public async Task<string?> LoginAsync(string correo, string contrasena)
        {
            var cliente = await _context.Clientes
                .FirstOrDefaultAsync(c => c.Correo == correo && c.Contrasena == contrasena);

            if (cliente == null)
                return null;

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, cliente.IdCliente.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, cliente.Correo),
                new Claim("nombre", cliente.Nombre)
            };

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(Convert.ToDouble(_config["Jwt:ExpireMinutes"])),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}

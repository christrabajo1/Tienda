﻿using Tienda.Data.Entities;

namespace Tienda.Business.Interfaces
{
    public interface ICarritoService
    {
        Task<Carrito> CrearCarritoAsync(int idCliente);
        Task<CarritoDetalle> AgregarArticuloAsync(int idCarrito, int idArticulo, int cantidad);
        Task<Carrito?> ObtenerCarritoAsync(int idCliente);
        Task<bool> EliminarArticuloAsync(int idCarrito, int idArticulo);
        Task<bool> VaciarCarritoAsync(int idCarrito);

        Task<Carrito?> ObtenerCarritoAsyncPorId(int idCarrito);
    }
}

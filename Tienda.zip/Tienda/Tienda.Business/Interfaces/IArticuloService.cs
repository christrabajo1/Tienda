﻿using Tienda.Data.Entities;

namespace Tienda.Business.Interfaces
{
    public interface IArticuloService : IGenericService<Articulo>
    {
        Task<IEnumerable<Articulo>> BuscarPorDescripcionAsync(string descripcion);
        Task<IEnumerable<Articulo>> ObtenerPorTiendaAsync(int idTienda);
    }
}


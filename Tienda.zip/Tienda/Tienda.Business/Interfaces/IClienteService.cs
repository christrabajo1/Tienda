﻿using Tienda.Data.Entities;

namespace Tienda.Business.Interfaces
{
    public interface IClienteService : IGenericService<Cliente>
    {
        Task<IEnumerable<Cliente>> BuscarPorNombreAsync(string nombre);
    }
}

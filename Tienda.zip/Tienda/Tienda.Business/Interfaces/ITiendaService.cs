﻿
using TiendaEntity = Tienda.Data.Entities.Tienda; 

namespace Tienda.Business.Interfaces
{
    public interface ITiendaService : IGenericService<TiendaEntity>
    {
        Task<IEnumerable<TiendaEntity>> BuscarPorSucursalAsync(string nombreSucursal);
    }
}


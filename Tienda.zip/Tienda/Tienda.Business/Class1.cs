﻿namespace Tienda.Business
{
    public class Class1
    {

    }
}
